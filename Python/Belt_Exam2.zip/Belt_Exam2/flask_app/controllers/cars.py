from flask_app import app
from flask import render_template, request, redirect, session,flash
from flask_app.models import user,car

@app.route('/dashboard')
def dashboard():
    if "user_id" not in session:
        return redirect('/')
    logged_in_user = user.User.get_by_id(session["user_id"])
    # logged_in_user = user.User.get_by_id(data)
    cars = car.Cars.get_all_car()
    return render_template('dashboard.html', logged_in_user = logged_in_user, cars = cars)

@app.route('/car/new')
def add_car():
    if "user_id" not in session:
        return redirect('/')
    logged_in_user = user.User.get_by_id(session["user_id"])
    return render_template("add_car.html",logged_in_user=logged_in_user)

# # CREATE CAR POST METHOD
@app.route('/add-car', methods = ['POST'])
def create_car():
    if "user_id" not in session:
        return redirect("/")
    if car.Cars.validate_car(request.form):
        car.Cars.create_car(request.form)
        return redirect("/dashboard")
    return redirect("/car/new")

# SHOW TREE 
@app.route("/show/<int:id>")
def get_car(id):
    if "user_id" not in session:
        return redirect("/")
    logged_in_user = user.User.get_by_id(session["user_id"])
    show_car = car.Cars.get_car(id)
    return render_template("details.html",logged_in_user=logged_in_user ,show_car=show_car)

# UPDATE TREE
@app.route("/edit/<int:id>")
def edit_car(id):
    if "user_id" not in session:
        return redirect("/")
    logged_in_user = user.User.get_by_id(session["user_id"])
    edit_car = car.Cars.get_car(id)
    return render_template("edit.html",logged_in_user=logged_in_user, car=edit_car)

@app.route("/edit_car/<int:id>",methods=["POST"])
def update_car(id):
    if "user_id" not in session:
            return redirect("/")
    if car.Cars.validate_car(request.form):
        car.Cars.update_car(request.form)
        return redirect(f"/show/{id}")
    return redirect(f"/edit/{id}")

# DELETE TREE
@app.route("/cars/delete/<int:id>")
def delete_cars(id):
    if "user_id" not in session:
        return redirect("/")
    car.Cars.delete_car(id)
    return redirect("/user/account")

@app.route("/user/account")
def my_cars():
    if "user_id" not in session:
        return redirect("/")
    logged_in_user = user.User.get_by_id(session["user_id"])
    cars = car.Cars.get_user_cars(logged_in_user.id)
    return render_template("my_cars.html",logged_in_user=logged_in_user, cars = cars)