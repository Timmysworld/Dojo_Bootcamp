from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_app import app 
from flask_app.models import user
import re
PRICE_REGEX  = re.match(r'\d+(?:[.]\d{2})?$', '40.12')
### fat model - most of the logic is done here####

class Cars:
    db ="Car Deals"
    def __init__(self,data):
        self.id = data['id']
        self.make = data['make']
        self.model = data['model']
        self.year = data['year']
        self.price = data['price']
        self.description = data['description']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.user_id = data["user_id"]
        self.seller = None # accesses the User class

    @staticmethod
    def validate_car(car):
        is_valid = True
        if len(car['make'])< 3:
            flash("name of car needs to be at least 5 character.", "car")
            is_valid = False
        if len(car['model']) == 0:
            flash("You must put a model.","car")
            is_valid = False
        if len(car['year']) == 0:
            flash("Please tell us the year", "car")
            is_valid = False
        if len(car['description']) == 0:
            flash('Please tell us about your car', "car")
        if  len(car['price']) == 0:
            flash("how much does it cost?", "car")
            is_valid = False
        
        return is_valid

#CREATE 
    @classmethod
    def create_car(cls, data):
        query = """
        INSERT INTO cars (make,model,year,price,description,user_id)
        Values (%(make)s, %(model)s, %(year)s, %(price)s, %(description)s, %(user_id)s);"""
        return connectToMySQL(cls.db).query_db(query,data)

#READ   
    @classmethod
    def get_all_car(cls):
        query = """
        SELECT * FROM cars 
        JOIN users ON cars.user_id = users.id;
        """
        results = connectToMySQL(cls.db).query_db(query)
        cars= []
        
        for row in results: 
            car = cls(row)
            seller_info = {
                "id": row["user_id"],
                "first_name": row["first_name"],
                "last_name":row["last_name"],
                "email":row["email"],
                "password":row["password"],
                "created_at":row["created_at"],
                "updated_at":row["updated_at"]
            }
            seller = user.User(seller_info)
            car.seller = seller
            cars.append(car)
        return cars

#UPDATE 
    @classmethod
    def get_car(cls,car_id):
        data = {"id": car_id}
        query = """
        SELECT * FROM cars 
        JOIN users ON cars.user_id = users.id 
        WHERE cars.id = %(id)s;
        """
        results = connectToMySQL(cls.db).query_db(query,data)
        car = cls(results[0])
        seller_info = {
                "id": results[0]["user_id"],
                "first_name": results[0]["first_name"],
                "last_name":results[0]["last_name"],
                "email":results[0]["email"],
                "password":results[0]["password"],
                "created_at":results[0]["created_at"],
                "updated_at":results[0]["updated_at"]
            }
        seller = user.User(seller_info)
        car.seller = seller
        return car
    
    @classmethod
    def update_car(cls,data):
        query = """
        UPDATE cars SET 
        make = %(make)s, model = %(model)s, year = %(year)s, price = %(price)s, description = %(description)s, user_id = %(user_id)s 
        WHERE cars.id = %(id)s;
        """
        return connectToMySQL(cls.db).query_db(query,data)


    @classmethod
    def get_user_cars(cls,user_id):
        data={"user_id":user_id}
        query = """
        SELECT * FROM cars WHERE cars.user_id = %(user_id)s;
        """
        results = connectToMySQL(cls.db).query_db(query,data)
        cars = []
        for row in results:
            car = cls(row)
            cars.append(car)
        return cars
    
#DELETE
    @classmethod
    def delete_car(cls,car_id):
        data = {"id":car_id}
        query = """
        DELETE FROM cars WHERE id=%(id)s;
        """
        return connectToMySQL(cls.db).query_db(query,data)