from flask_app import app
from flask import render_template, request, redirect, session,flash
from flask_app.models import user,arbortrary


@app.route('/dashboard')
def dashboard():
    if "user_id" not in session:
        return redirect('/')
    logged_in_user = user.User.get_by_id(session["user_id"])
    # logged_in_user = user.User.get_by_id(data)
    trees = arbortrary.Arbortrary.get_all_arbortrary()
    return render_template('dashboard.html', logged_in_user = logged_in_user, trees = trees)

@app.route('/tree/new')
def add_tree():
    if "user_id" not in session:
        return redirect('/')
    logged_in_user = user.User.get_by_id(session["user_id"])
    return render_template("add_tree.html",logged_in_user=logged_in_user)

@app.route('/add-tree', methods = ['POST'])
def create_tree():
    if "user_id" not in session:
        return redirect("/")
    if arbortrary.Arbortrary.validate_arbortrary(request.form):
        arbortrary.Arbortrary.create_tree(request.form)
        return redirect("/dashboard")
    return redirect("/tree/new")

@app.route("/show/<int:id>")
def get_tree(id):
    if "user_id" not in session:
        return redirect("/")
    logged_in_user = user.User.get_by_id(session["user_id"])
    show_tree = arbortrary.Arbortrary.get_tree(id)
    return render_template("details.html",logged_in_user=logged_in_user ,show_tree=show_tree)

@app.route("/edit/<int:id>")
def edit_book(id):
    if "user_id" not in session:
        return redirect("/")
    logged_in_user = user.User.get_by_id(session["user_id"])
    edit_tree = arbortrary.Arbortrary.get_tree(id)
    return render_template("edit.html",logged_in_user=logged_in_user, tree=edit_tree)

@app.route("/edit_tree/<int:id>",methods=["POST"])
def update_tree(id):
    if "user_id" not in session:
            return redirect("/")
    if arbortrary.Arbortrary.validate_arbortrary(request.form):
        arbortrary.Arbortrary.update_tree(request.form)
        return redirect(f"/show/{id}")
    return redirect(f"/edit_tree/{id}")


@app.route("/user/account")
def my_trees():
    if "user_id" not in session:
        return redirect("/")
    logged_in_user = user.User.get_by_id(session["user_id"])
    trees = arbortrary.Arbortrary.get_user_trees(logged_in_user.id)
    return render_template("my_trees.html",logged_in_user=logged_in_user, trees = trees)

@app.route("/trees/delete/<int:id>")
def delete_trees(id):
    if "user_id" not in session:
        return redirect("/")
    arbortrary.Arbortrary.delete_tree(id)
    return redirect("/user/account")