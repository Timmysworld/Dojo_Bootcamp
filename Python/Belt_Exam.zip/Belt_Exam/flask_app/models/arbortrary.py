from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_app import app 
from flask_app.models import user

class Arbortrary:
    db ="Arbortrary"
    def __init__(self,data):
        self.id = data['id']
        self.species = data['species']
        self.location = data['location']
        self.reason = data['reason']
        self.date_planted = data['date_planted']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.user_id = data["user_id"]
        self.planter = None # accesses the User class

    @staticmethod
    def validate_arbortrary(arbortrary):
        is_valid = True
        if len(arbortrary['species'])< 5:
            flash("Name needs to be at least 5 character.", "arbortrary")
            is_valid = False
        if len(arbortrary['location']) == 0:
            flash("You must place a location.","arbortrary")
            is_valid = False
        if len(arbortrary['reason']) == 0:
            flash("Please specify your reasons", "arbortrary")
            is_valid = False
        if not arbortrary['date_planted']:
            flash("when did you plant it", "arbortrary")
            is_valid = False
        return is_valid

    @classmethod
    def create_tree(cls, data):
        query = """
        INSERT INTO arbortraries (species,location,reason,date_planted,user_id)
        Values (%(species)s, %(location)s, %(reason)s, %(date_planted)s, %(user_id)s);"""
        return connectToMySQL(cls.db).query_db(query,data)
    
    @classmethod
    def get_all_arbortrary(cls):
        query = """
        SELECT * FROM arbortraries 
        JOIN users ON arbortraries.user_id = users.id;
        """
        results = connectToMySQL(cls.db).query_db(query)
        trees= []
        
        for row in results: 
            tree = cls(row)
            planter_info = {
                "id": row["user_id"],
                "first_name": row["first_name"],
                "last_name":row["last_name"],
                "email":row["email"],
                "password":row["password"],
                "created_at":row["created_at"],
                "updated_at":row["updated_at"]
            }
            planter = user.User(planter_info)
            tree.planter = planter
            trees.append(tree)
            return trees

    @classmethod
    def get_tree(cls,tree_id):
        data = {"id": tree_id}
        query = """
        SELECT * FROM arbortraries 
        JOIN users ON arbortraries.user_id = users.id 
        WHERE arbortraries.id = %(id)s;
        """
        results = connectToMySQL(cls.db).query_db(query,data)
        tree = cls(results[0])
        return tree
    
    @classmethod
    def update_tree(cls,data):
        query = """
        UPDATE arbortraries SET 
        species = %(species)s, location = %(location)s, reason = %(reason)s, date_planted = %(date_planted)s, user_id = %(user_id)s 
        WHERE arbortraries.id = %(id)s;
        """
        return connectToMySQL(cls.db).query_db(query,data)


    @classmethod
    def get_user_trees(cls,user_id):
        data={"user_id":user_id}
        query = """
        SELECT * FROM arbortraries WHERE arbortraries.user_id = %(user_id)s;
        """
        results = connectToMySQL(cls.db).query_db(query,data)
        trees = []
        for row in results:
            tree = cls(row)
            trees.append(tree)
        return trees
    

    @classmethod
    def delete_tree(cls,tree_id):
        data = {"id":tree_id}
        query = """
        DELETE FROM arbortraries WHERE id=%(id)s;
        """
        return connectToMySQL(cls.db).query_db(query,data)