function hide(element){
    element.remove();
}

function my_pet(element){
    var animalChoice = document.getElementById("typeofpet").value;
    alert("You are looking for a " + " " + animalChoice);
}
var number = [ 3,5,8]; // [0,1,2]  parameters of each button position 
var count = document.querySelectorAll("span"); 
// console.log(count);

function increasePets(id){ //passing [id] to grab index from var number array.
    number[id]++; //increases the number of every time button is clicked
    count[id].innerText = number[id]; 
    // console.log(id);
}

